import { BrowserRouter, Link, Route, Routes } from "react-router-dom"
import Home from "./Components/Home"
import About from "./Components/About"
import Contact from "./Components/Contact"
import Register from "./Components/Register"
import Login from "./Components/Login"
import Menu from "./Components/Menu"

/*
function App() {
   return<div>
    
          <BrowserRouter>
             <Link to="/">Home</Link>&nbsp;&nbsp;
			      <Link to="/about">About</Link>&nbsp;&nbsp;
			     <Link to="/contact">Contact</Link>&nbsp;&nbsp;
			    <Link to="/help">Help</Link>&nbsp;&nbsp;
			     <Link to="/login">Login</Link>&nbsp;&nbsp;
           
          </BrowserRouter> 
   </div> 
}

export default App
*/

/*
function App() {
  return<div>
   
         <BrowserRouter>
            <Link to="/">Home</Link>&nbsp;&nbsp;
           <Link to="/about">About</Link>&nbsp;&nbsp;
          <Link to="/contact">Contact</Link>&nbsp;&nbsp;
         <Link to="/register">Register</Link>&nbsp;&nbsp;
          <Link to="/login">Login</Link>&nbsp;&nbsp;
          
          <Routes>
          <Route path="/" element={<Home/>}></Route>
			  <Route path="/about" element={<About/>}></Route>
			  <Route path="/contact" element={<Contact/>}></Route>
			  <Route path="/register" element={<Register/>}></Route>
			  <Route path="/login" element={<Login/>}></Route>
          </Routes>
         </BrowserRouter> 
  </div> 
}

export default App
*/

/*
function App() {
  return<div>
   
      <BrowserRouter>
          <Menu/>
        <Routes>
          <Route path="/" element={<Home/>}></Route>
			    <Route path="/about" element={<About/>}></Route>
			    <Route path="/contact" element={<Contact/>}></Route>
			    <Route path="/register" element={<Register/>}></Route>
			    <Route path="/login" element={<Login/>}></Route>
        </Routes>
      </BrowserRouter> 
  </div> 
}

export default App
*/

function App() {
  return<div>
   
          <Menu/>
        <Routes>
          <Route path="/" element={<Home/>}></Route>
			    <Route path="/about" element={<About/>}></Route>
			    <Route path="/contact" element={<Contact/>}></Route>
			    <Route path="/register" element={<Register/>}></Route>
			    <Route path="/login" element={<Login/>}></Route>
        </Routes>
    </div> 
}

export default App