function Home()
{
    return<div style={{textAlign:'center'}}>
      <h1>Home Page Called...</h1>    
    </div>
}
export default Home