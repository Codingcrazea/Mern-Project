function Contact()
{
    return<div style={{textAlign:'center'}}>
      <h1>Contact Page Called...</h1>    
    </div>
}
export default Contact