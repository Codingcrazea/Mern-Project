import { Link } from "react-router-dom"

function Menu()
{
    return<div style={{textAlign:'center'}}>
        <Link to="/">Home</Link>&nbsp;&nbsp;
           <Link to="/about">About</Link>&nbsp;&nbsp;
          <Link to="/contact">Contact</Link>&nbsp;&nbsp;
         <Link to="/register">Register</Link>&nbsp;&nbsp;
          <Link to="/login">Login</Link>&nbsp;&nbsp;
    </div>
}
export default Menu