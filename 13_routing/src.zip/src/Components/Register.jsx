function Register()
{
    return<div style={{textAlign:'center'}}>
      <h1>Register Page Called...</h1>    
    </div>
}
export default Register