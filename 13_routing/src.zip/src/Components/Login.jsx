function Login()
{
    return<div style={{textAlign:'center'}}>
      <h1>Login Page Called...</h1>    
    </div>
}
export default Login