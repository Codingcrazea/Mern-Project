//import { context } from "./App";
import MyContext from './MyContext.jsx'
function Display()
{
  return<div>
    <h1>Display Component Called : </h1>
    {/*
    <context.Consumer>
        {data=><b>{data}</b>}
    </context.Consumer>
    */}
{/* 
    <context.Consumer>
        {data=>data.map((res,index)=>{
              return<b>{index+1} : {res} <br/></b>
        })}
    </context.Consumer>
   */}

<MyContext.Consumer>
        {data=>data.map((res,index)=>{
              return<b>{index+1} : {res} <br/></b>
        })}
    </MyContext.Consumer>

    </div>
}
export default Display;