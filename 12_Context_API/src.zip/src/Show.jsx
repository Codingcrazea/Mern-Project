import Wish from "./Wish.jsx";

function Show()
{
  return<div>
    <h1>Show Component Called : </h1>
    <hr/>
    <Wish/>
  </div>
}
export default Show;