import React, { useState } from "react";
import Show from "./Show.jsx";

//export const context = React.createContext()
import MyContext from './MyContext.jsx'

function App()
{
 // const [name,setName] = useState("Mahi");
    const [arr,setArr] = useState([11,21,23,44,46,21,23,22,34,67])
  
  return<div>
    <h1>App Component Called : </h1>
   {/* <b>{name}</b> */}
    <hr/>
    {/*
    <context.Provider value={name}>
       <Show/>
    </context.Provider>
    */}

{/*
   <context.Provider value={arr}>
       <Show/>
    </context.Provider>
  */}

<MyContext.Provider value={arr}>
       <Show/>
    </MyContext.Provider>
    </div>

  
  }
export default App;