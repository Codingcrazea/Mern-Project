import Display from "./Display.jsx";

function Wish()
{
  return<div>
    <h1>Wish Component Called : </h1>
    <Display/>
  </div>
}
export default Wish;