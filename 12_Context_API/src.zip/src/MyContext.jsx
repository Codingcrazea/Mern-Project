import React from "react";
var context = React.createContext()

export default context;