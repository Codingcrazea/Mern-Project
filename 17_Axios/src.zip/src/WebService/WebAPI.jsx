export default{
    loginAPI:"http://tutorials.codebetter.in:7084/auth/login",
    registerAPI:'http://tutorials.codebetter.in:7084/auth/save'
}